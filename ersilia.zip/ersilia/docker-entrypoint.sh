#!/bin/bash
echo "Running Ersilla Setup..."
setup-ersilia
echo "Erisilla Environment has been configured"
bash